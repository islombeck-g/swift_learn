//
//  jsonApiTestApp.swift
//  jsonApiTest
//
//  Created by Islombek Gofurov on 04.12.2022.
//

import SwiftUI

@main
struct jsonApiTestApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
