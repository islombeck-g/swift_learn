
import SwiftUI

@main
struct someWorkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
