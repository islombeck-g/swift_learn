//
//  urlFile.swift
//  someWork
//
//  Created by Islombek Gofurov on 25.01.2023.
//

import Foundation
//
//let url = URL(string: "http://143.47.237.139/maincountrynone-znhs/")!
//
//let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
//    guard let data = data else { return }
//    print(String(data: data, encoding: .utf8)!)
//    do{
//        let hhhr = try JSONDecoder().decode(Dane.self, from: data)
//        let furl = hhhr.url
//        print(furl)
//        
//        if furl.isEmpty{
//            
//        }else{
//            DispatchQueue.main.async {
//                let sb = UIStoryboard(name: "Main", bundle:nil)
//                let inicialVC = sb.instantiateViewController(withIdentifier: "vc")as!TwooViewController
//                self.present(inicialVC,animated: false,completion: nil)
//            }
//            
//            
//        }
//    }catch let error{
//        print(error)
//        
//    }
//    
//    
//}
//
//task.resume()
//}
